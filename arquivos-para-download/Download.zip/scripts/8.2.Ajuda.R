#Formacao Inteligencia Artificial e Machine Learning - Fernando Amaral

help(sd)