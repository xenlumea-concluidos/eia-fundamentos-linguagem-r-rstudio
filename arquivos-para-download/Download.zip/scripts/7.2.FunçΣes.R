#Formacao Inteligencia Artificial e Machine Learning - Fernando Amaral

head(x=iris, n=2)
head(iris)
head(iris,2)
head(n=22)

