#Formacao Inteligencia Artificial e Machine Learning - Fernando Amaral

delta <- 8
class(delta)

delta = 8L
class(delta)


logico <- TRUE
logico <- F
caractere <- "Texto"
caractere <- 'Texto'


c = 2
d = 4
(c + d) * d
e = (c + d) * d
e


a = 1
b = 2
a < b
a == b

sqrt(2500)