#Formacao Inteligencia Artificial e Machine Learning - Fernando Amaral

install.packages("e1071", dependencies = TRUE)
library(e1071)
