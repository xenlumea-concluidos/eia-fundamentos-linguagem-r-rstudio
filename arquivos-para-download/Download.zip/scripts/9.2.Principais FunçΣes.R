esoph
#default 6 linhas
head(esoph)
tail(esoph)
#10 linhas
head(esoph, n=10)

dim(esoph)

#se usar com objeto bi dimensional vai retornar colunas
length(islands )


colnames(esoph)


rownames(esoph)

summary(esoph)


x = file.choose()
x



